# 소싱 도우미 — 크롬 확장 (v0.2)

소싱 웹앱의 **도매몰 소싱** 탭에서 키워드를 검색하면, 이 확장이 **로그인된 브라우저 세션**으로
각 도매몰(유픽·건강산·건온연·엠에스굿포유)을 검색해 **가격 낮은 순**으로 정리합니다.
상품별 📥 버튼으로 **썸네일 + 상세 이미지**도 한 번에 저장합니다.
**비밀번호는 저장하지 않습니다.**

## 설치 (최초 1회)
1. 크롬 주소창에 `chrome://extensions` 입력
2. 오른쪽 위 **개발자 모드** 켜기
3. **압축해제된 확장 프로그램을 로드합니다** 클릭
4. 이 폴더(`manifest.json` 이 있는 폴더) 선택
5. 목록에 "소싱 도우미"가 뜨면 완료 → **웹앱 페이지를 Ctrl+F5 로 새로고침**

> 회원용 그림 설명서는 웹앱의 `install.html` (도매몰 소싱 탭 → "확장 설치 안내") 참고.

## 사용
1. 검색할 **도매몰에 먼저 로그인** (사업자 승인 계정이어야 상품이 보임)
2. 웹앱 → **도매몰 소싱** 탭 → 키워드 + 도매몰 선택 → **검색**
3. 결과의 📥 → 폴더명 입력 → `다운로드\<폴더명>\` 에 `1`(썸네일) + `s1,s2…`(상세) 저장
   - 첫 다운로드 때 크롬이 "여러 파일 허용"을 물어보면 **허용**

## 동작 방식
- `bridge.js`(콘텐츠 스크립트, localhost·github.io)가 웹앱의 `window.postMessage` 요청을 받음
- `background.js`가 검색/상세 URL을 **숨김 탭**(`chrome.tabs.create active:false`)으로 열고
  로그인 세션 상태에서 `chrome.scripting.executeScript` 로 DOM 파싱
- 이미지는 `chrome.downloads` 로 저장 (CORS 무관, 외부 CDN도 가능)
- MV3 서비스워커에는 DOMParser 가 없어 **탭 방식**을 사용

## 사이트별 설정 (background.js)
| 도매몰 | 플랫폼 | 검색 URL | 상품카드 | 이미지 |
|---|---|---|---|---|
| upickb2b(유픽) | Cafe24 | `/product/search.html?keyword=` | `ul.prdList > li` | 썸네일 `img[src*="/web/product/big/"]` · 상세 `img[ec-data-src]` |
| ggsan(건강산) | 고도몰 | `/goods/goods_search.php?keyword=` | `.item_cont` 등 | 제네릭(og:image + 큰 이미지) |
| gonyb2b(건온연) | 영카트 | `/shop/search.php?q=` | `li:has(.price)` | 썸네일 `.popup_item_image img` · 상세 `#sit_inf_explan img` |
| msgood4u(엠에스굿포유) | 기타 | `www.` + `/html/search/search.php?skey=all&directsearch=y&searchTerm=&sword=` | `li.line_4` | 썸네일 `.swiper-slide img` (상세 없음) |

가격 추출(`priceOf`)은 정책 문구 줄(스마트스토어/쿠팡/등록가능 등)을 걷어낸 뒤
**회원가·공급가 라벨을 우선**하고, 없으면 '원'이 붙은 금액 중 **최솟값**(도매가)을 씁니다.

## 수정할 때
- `background.js` 를 고치면 `chrome://extensions` 에서 해당 카드의 **🔄** 를 눌러 리로드해야 반영됩니다.
- 도매몰이 HTML 구조를 바꾸면 `SITES[*].cards` 또는 `pageImages()` 셀렉터를 조정합니다.
  (튜닝은 로그인 상태에서 콘솔로 요소·이미지 크기를 덤프해 확인)
- 회원 배포용 zip 은 `python ../make_deploy.py` 가 `배포/sourcing-helper.zip` 으로 만들어 줍니다.
