// 웹앱 ↔ 확장 다리 (콘텐츠 스크립트). 웹앱은 window.postMessage 로 요청, 결과를 받음.
//
// ⚠ 확장을 리로드(chrome://extensions 의 🔄)하면 이미 열려 있던 페이지의 이 스크립트는
//   고아가 되어 chrome.runtime 이 사라진다. 그 상태로 sendMessage 를 부르면
//   "Cannot read properties of undefined" 로 조용히 죽으므로, 미리 확인해서
//   웹앱에 "새로고침하세요" 라고 알려준다.
const alive = () => {
  try { return !!(chrome && chrome.runtime && chrome.runtime.id); }
  catch (e) { return false; }
};
const STALE = "확장이 업데이트되어 연결이 끊겼습니다. 이 페이지를 새로고침(Ctrl+F5)한 뒤 다시 시도해 주세요.";

window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data || e.data.__srcReq !== true) return;
  const { __srcReq, id, ...payload } = e.data;   // action/keyword/malls 또는 action/link/folder 등 전달

  if (!alive()) {
    window.postMessage({ __srcRes: true, id, ok: false, stale: true, error: STALE }, "*");
    return;
  }
  try {
    chrome.runtime.sendMessage(payload, (resp) => {
      const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
      window.postMessage(Object.assign({ __srcRes: true, id, ok: !err && resp && resp.ok, error: err }, resp || {}), "*");
    });
  } catch (err) {
    window.postMessage({ __srcRes: true, id, ok: false, stale: true, error: STALE }, "*");
  }
});

// 웹앱에 확장 설치됨을 알림
window.postMessage({ __srcReady: true }, "*");
