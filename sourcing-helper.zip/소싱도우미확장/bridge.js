// 웹앱 ↔ 확장 다리 (콘텐츠 스크립트). 웹앱은 window.postMessage 로 요청, 결과를 받음.
window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data || e.data.__srcReq !== true) return;
  const { __srcReq, id, ...payload } = e.data;   // action/keyword/malls 또는 action/link/folder 등 전달
  chrome.runtime.sendMessage(payload, (resp) => {
    const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
    window.postMessage(Object.assign({ __srcRes: true, id, ok: !err && resp && resp.ok, error: err }, resp || {}), "*");
  });
});
// 웹앱에 확장 설치됨을 알림
window.postMessage({ __srcReady: true }, "*");
