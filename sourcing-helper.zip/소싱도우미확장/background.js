// 소싱 도우미 — 백그라운드 서비스워커
// 각 도매몰 검색 페이지를 숨김 탭으로 열어(로그인 세션 사용) DOM 파싱 → 가격순 정리.

const TOPN = 8;   // 사이트별 최저가 몇 개까지

// 도매몰 설정: 검색 URL + 상품카드 후보 셀렉터 (사이트 구조 바뀌면 여기만 수정)
const SITES = {
  upickb2b: { name: "유픽", platform: "Cafe24",
    url: kw => `https://upickb2b.com/product/search.html?keyword=${encodeURIComponent(kw)}`,
    cards: ["ul.prdList > li", ".xans-product-listnormal li", ".ec-base-product li", "li.xans-record-"] },
  ggsan: { name: "건강산", platform: "고도몰",
    url: kw => `https://ggsan.com/goods/goods_search.php?keyword=${encodeURIComponent(kw)}`,
    cards: [".item_cont", ".goods_list li", "ul.prdList li", ".item_gallery_type li", "li.item"] },
  gonyb2b: { name: "건온연", platform: "영카트",
    url: kw => `https://gonyb2b.com/shop/search.php?q=${encodeURIComponent(kw)}`,
    cards: ["li:has(.price)", "div.product li:has(.txt)", ".sct_li"] },
  msgood4u: { name: "엠에스굿포유", platform: "기타",
    url: kw => `https://www.msgood4u.com/html/search/search.php?skey=all&directsearch=y&searchTerm=&sword=${encodeURIComponent(kw)}`,
    cards: ["li.line_4", ".PJ_goods_border", "div.list li"] },
};

// ── 페이지 컨텍스트에서 실행되는 파서 (숨김 탭 안에서 동작) ──
function pageParse(cardSelectors) {
  const priceOf = (raw) => {
    // 판매 정책/마케팅 문구 줄 제거 (예: "스마트스토어,쿠팡 19900원이상 등록가능")
    const s = String(raw).split("\n")
      .filter(line => !/스마트스토어|쿠팡|등록\s*가능|판매가\s*절대|절대\s*준수|키워드\s*주의|이상\s*등록/.test(line))
      .join("\n");
    // 1) 도매가 라벨(회원가/공급가/도매가/판매가/B2B가) 뒤의 '원' 금액 우선
    let m = s.match(/(?:회원가|공급가|도매가|판매가|B2B가|납품가)[^\d]{0,8}([\d,]{3,})\s*원/);
    if (m) return parseInt(m[1].replace(/,/g, ""), 10);
    // 2) 그 외 '원' 금액들 중 최솟값 (소비자가·정책가보다 낮은 도매가)
    const all = [...s.matchAll(/([\d,]{3,})\s*원/g)]
      .map(x => parseInt(x[1].replace(/,/g, ""), 10)).filter(n => n >= 100 && n < 100000000);
    return all.length ? Math.min(...all) : null;
  };
  let items = [];
  for (const sel of cardSelectors) {
    const els = Array.from(document.querySelectorAll(sel));
    if (els.length) { items = els; break; }
  }
  const out = [];
  for (const el of items) {
    const a = el.querySelector("a[href]");
    const img = el.querySelector("img");
    const link = a ? a.href : "";
    let thumb = img ? (img.getAttribute("src") || img.getAttribute("ec-data-src") || img.getAttribute("data-src") || "") : "";
    if (thumb && thumb.startsWith("//")) thumb = "https:" + thumb;
    let name = (img && img.alt && img.alt.trim().length > 4) ? img.alt.trim() : "";
    if (!name) {
      // 폴백: 가격/단위/UI라벨/공급사 아닌 줄 중 '가장 긴 줄'을 제품명으로
      const lines = (el.innerText || "").split("\n").map(s => s.trim())
        .filter(t => t.length > 5 && !/원\s*$/.test(t)
          && !/^[\d,.\sgxml개포정병캡슐]+$/i.test(t)
          && !/스마트스토어|쿠팡|등록\s*가능|판매가\s*절대|절대\s*준수|키워드\s*주의/.test(t)
          && !/^(품절|할인|신상품|추천|BEST|NEW|WISH|ADD|찜|장바구니|바로구매|모든마켓|자체상품코드|상품코드|회원가|공급가)/.test(t));
      lines.sort((a, b) => b.length - a.length);
      name = lines[0] || (el.innerText || "").split("\n").map(s => s.trim()).filter(Boolean)[0] || "";
    }
    const price = priceOf(el.innerText || "");
    if (name) out.push({ name: name.slice(0, 90), price, thumb, link });
  }
  return out;
}

// ── 쿠팡 검색결과 파서 (페이지 컨텍스트에서 실행) ──
// 카드 = [class*='ProductUnit_productUnit'] (LI). 한 페이지 60개.
// 광고는 카드 텍스트의 '광고' 또는 링크의 sourceType=srp_product_ads 로 판별(실측 일치).
async function pageCoupang(topN) {
  const SEL = "[class*='ProductUnit_productUnit']";
  // 검색 결과는 서버에서 내려오지만, 리다이렉트나 봇 검사 페이지를 거치면
  // executeScript 가 그 중간 페이지에서 돌 수 있다. 카드가 보일 때까지 최대 10초 기다린다.
  for (let i = 0; i < 50 && document.querySelectorAll(SEL).length === 0; i++) {
    await new Promise(r => setTimeout(r, 200));
  }
  const body = (document.body && document.body.innerText || "").slice(0, 600);
  const blocked = /로봇이 아닙니다|자동화된|비정상적인 접근|Access Denied|잠시 후 다시 시도|보안 문자|캡차|captcha|일시적으로 제한|접속이 원활하지/i.test(body);

  const pidOf = (h) => (String(h).match(/\/vp\/products\/(\d+)/) || [])[1] || "";
  // 썸네일 URL 에서 크기·화질 옵션(/remote/657x657q90trim/)을 떼어 비교용 키로
  const imgKey = (s) => {
    if (!s) return "";
    const m = String(s).match(/\/remote\/[^/]+\/(.+)$/);
    return (m ? m[1] : String(s)).split("?")[0].toLowerCase();
  };
  // "본체, 옵션명, 수량" → 첫 쉼표 앞 본체만 (공백·기호 제거)
  const nameKey = (n) => String(n).split(",")[0].toLowerCase().replace(/[\s\[\]()/_+·-]/g, "");

  const cards = Array.from(document.querySelectorAll("[class*='ProductUnit_productUnit']"));
  // ★ '상위 N칸' 을 먼저 자른 뒤 그 안에서 광고를 뺀다.
  //   (광고를 빼고 N개를 채우면 소비자가 보지 않는 아래쪽까지 내려가 장악도 판단이 흐려짐)
  const slots = cards.slice(0, topN);
  const items = [];
  let ads = 0, skipped = 0;
  for (const c of slots) {
    const a = c.querySelector("a[href]");
    const href = a ? a.getAttribute("href") : "";
    const txt = c.innerText || "";
    if (/광고/.test(txt) || /sourceType=srp_product_ads/i.test(href)) { ads++; continue; }
    const pid = pidOf(href);
    if (!pid) { skipped++; continue; }
    const img = c.querySelector("img");
    const src = img ? (img.getAttribute("src") || img.getAttribute("data-img-src") || img.getAttribute("data-src") || "") : "";
    const name = (txt.split("\n").map(s => s.trim()).filter(Boolean)[0] || "");
    // ── 로켓(쿠팡 물류) 판별 ──
    // 배송 배지는 글자가 아니라 이미지이고, 파일명은 해시라 '경로 폴더명'에만 의미가 있다.
    //   logo_rocket_filter        로켓배송
    //   logo_rocket_merchant      판매자로켓
    //   logo_fresh                로켓프레시
    //   rds_logo_pdd_today/…      오늘·내일·새벽 도착보장 (쿠팡 물류)
    // logo_wow 는 와우 회원 혜택 배지라 배송과 무관 → 제외.
    // srcset 에만 들어 있는 경우가 있어 img 뿐 아니라 source 와 srcset/data-src 까지 본다.
    const badgeUrls = Array.from(c.querySelectorAll("img,source"))
      .map(e => [e.getAttribute("src"), e.getAttribute("srcset"), e.getAttribute("data-src")]
        .filter(Boolean).join(" ")).join(" ");
    const rocket = /logo_rocket|logo_fresh|rds_logo_pdd/i.test(badgeUrls);
    const rocketOwn = /logo_rocket_merchant/i.test(badgeUrls);   // 판매자로켓(내가 따라 할 수 있는 형태)
    items.push({ pid, name: name.slice(0, 80), img: imgKey(src), nk: nameKey(name), rocket, rocketOwn });
  }
  return {
    items, totalCards: cards.length, slots: slots.length, ads, skipped, blocked,
    // 카드를 못 찾았을 때 원인을 눈으로 확인하기 위한 값들
    url: location.href,
    title: document.title,
    bodyHead: body.replace(/\s+/g, " ").slice(0, 160),
    linkCount: document.querySelectorAll("a[href*='/vp/products/']").length,
  };
}

// ── 시크릿 창 관리 ──
// 쿠팡은 내 클릭·방문 이력으로 검색 결과 순위를 바꾼다. 시크릿 창에서 열면
// 쿠키·이력이 없는 상태로 보이므로 중립적인 순위를 얻을 수 있다.
// (chrome://extensions 에서 이 확장의 '시크릿 모드에서 허용' 을 켜야 동작)
let INCOG_WIN = null;
let INCOG_USES = 0;
const INCOG_MAX_USES = 20;   // 한 창을 오래 쓰면 세션이 쌓이므로 주기적으로 새로 연다

async function closeIncogWindow() {
  if (INCOG_WIN == null) return;
  const id = INCOG_WIN; INCOG_WIN = null; INCOG_USES = 0;
  try { await chrome.windows.remove(id); } catch (e) {}
}

async function ensureIncogWindow() {
  if (INCOG_WIN != null) {
    try { await chrome.windows.get(INCOG_WIN); }             // 사용자가 닫았을 수 있음
    catch (e) { INCOG_WIN = null; INCOG_USES = 0; }
  }
  if (INCOG_WIN != null && INCOG_USES >= INCOG_MAX_USES) await closeIncogWindow();
  if (INCOG_WIN == null) {
    let win;
    try {
      win = await chrome.windows.create({ url: "about:blank", incognito: true, state: "minimized" });
    } catch (e) {
      throw new Error("시크릿 창을 열 수 없습니다. chrome://extensions 에서 이 확장의 '시크릿 모드에서 허용'을 켜주세요.");
    }
    if (!win || !win.incognito) throw new Error("시크릿 창을 열 수 없습니다. chrome://extensions 에서 '시크릿 모드에서 허용'을 켜주세요.");
    INCOG_WIN = win.id; INCOG_USES = 0;
  }
  INCOG_USES++;
  return INCOG_WIN;
}

async function coupangScan(keyword, topN, incognito) {
  let tab;
  try {
    const url = `https://www.coupang.com/np/search?q=${encodeURIComponent(keyword)}&channel=user`;
    if (incognito) {
      const winId = await ensureIncogWindow();
      tab = await chrome.tabs.create({ url, active: false, windowId: winId });
    } else {
      tab = await chrome.tabs.create({ url, active: false });
    }
    await waitComplete(tab.id);
    await sleep(600);
    // lazy 이미지 로드를 위해 살짝 스크롤
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => new Promise(r => {
      let y = 0; const iv = setInterval(() => { window.scrollTo(0, y); y += 800; if (y > 3200) { clearInterval(iv); r(); } }, 70);
      setTimeout(() => { clearInterval(iv); r(); }, 2500);
    }) });
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageCoupang, args: [topN || 28] });
    if (!result) return { ok: false, keyword, error: "파싱 실패" };
    if (result.blocked) return { ok: false, keyword, blocked: true, error: "쿠팡이 자동 접근을 차단했습니다" };
    if (!result.items.length && !result.totalCards) {
      // 링크는 있는데 카드가 0 이면 진짜 구조 변경, 둘 다 0 이면 다른 페이지를 받은 것이다.
      const why = result.linkCount
        ? "상품 카드 구조가 바뀌었습니다"
        : `다른 페이지를 받았습니다 — ${result.title || "(제목 없음)"} / ${result.bodyHead || "(내용 없음)"}`;
      return { ok: false, keyword, error: why, diag: result };
    }
    return { ok: true, keyword, ...result };
  } catch (e) {
    return { ok: false, keyword, error: String(e && e.message || e) };
  } finally {
    if (tab) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function waitComplete(tabId) {
  return new Promise(res => {
    const li = (id, info) => { if (id === tabId && info.status === "complete") { chrome.tabs.onUpdated.removeListener(li); res(); } };
    chrome.tabs.onUpdated.addListener(li);
    setTimeout(() => { chrome.tabs.onUpdated.removeListener(li); res(); }, 15000);
  });
}

async function searchSite(key, kw) {
  const s = SITES[key];
  if (!s) return { mall: key, error: "알 수 없는 도매몰" };
  let tab;
  try {
    tab = await chrome.tabs.create({ url: s.url(kw), active: false });
    await waitComplete(tab.id);
    await sleep(1200);   // JS 렌더 여유
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageParse, args: [s.cards] });
    let list = (result || []).filter(p => p.name);
    // 가격 있는 것 우선 + 오름차순, 가격 없는 것은 뒤로
    list.sort((a, b) => (a.price == null) - (b.price == null) || (a.price || 0) - (b.price || 0));
    return { mall: key, name: s.name, count: list.length, items: list.slice(0, TOPN) };
  } catch (e) {
    return { mall: key, name: s.name, error: String(e && e.message || e) };
  } finally {
    if (tab) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

// ── 상세페이지에서 실행: 썸네일 + 상세 이미지 URL 수집 ──
function pageImages(host) {
  const abs = (u) => { if (!u) return ""; if (u.startsWith("//")) return "https:" + u; try { return new URL(u, location.href).href; } catch (e) { return u; } };
  let thumb = "", details = [];
  const pull = (im) => abs(im.getAttribute("ec-data-src") || im.getAttribute("data-src") || im.getAttribute("src"));
  if (host.includes("upickb2b")) {                 // Cafe24
    const t = document.querySelector('img[src*="/web/product/big/"]');
    thumb = t ? abs(t.getAttribute("src")) : "";
    // 상세페이지 이미지 = lazy 속성 ec-data-src 를 가진 img 만 (전체 페이지). 갤러리썸네일·아이콘(일반 src)은 제외.
    details = Array.from(document.querySelectorAll("img[ec-data-src]")).map(im => abs(im.getAttribute("ec-data-src")));
  } else if (host.includes("gonyb2b")) {           // 영카트 (건온연)
    const t = document.querySelector(".popup_item_image img, img[src*='_400x400']");
    thumb = t ? abs(t.getAttribute("src")) : "";
    const dc = document.querySelector("#sit_inf_explan");   // 상세설명 컨테이너(세로 긴 이미지)
    details = dc ? Array.from(dc.querySelectorAll("img")).map(pull) : [];
  } else if (host.includes("msgood4u")) {          // 엠에스굿포유
    const t = document.querySelector(".swiper-slide img, .goods_view .middle img, .middle img");
    thumb = t ? abs(t.getAttribute("src")) : "";
    const dc = document.querySelector("#goodsDetailHtmlContents");   // 상세(있으면)
    details = dc ? Array.from(dc.querySelectorAll("img")).map(pull) : [];
  } else {                                          // 제네릭 (건강산 등 — 튜닝 대상)
    const og = document.querySelector('meta[property="og:image"]');
    if (og && og.content) thumb = abs(og.content);
    if (!thumb) { const f = document.querySelector(".thumbnail img, .viewImg img, .image img, .big_img img"); if (f) thumb = abs(f.src); }
    const dc = document.querySelector("#prdDetail, .detail, .goods_description, .item_detail, .detail_cont, #productDescription, .goods_view") || document.body;
    details = Array.from(dc.querySelectorAll("img"))
      .filter(im => (im.naturalWidth >= 400) || (parseInt(im.getAttribute("width")) >= 400))
      .map(pull);
  }
  const seen = new Set();
  details = details.filter(u => u && !u.startsWith("data:") && !/sprite|icon|btn_|blank|loading/i.test(u) && !seen.has(u) && seen.add(u));
  return { thumb, details };
}

async function downloadProduct(link, folder) {
  let tab;
  try {
    const host = new URL(link).host;
    tab = await chrome.tabs.create({ url: link, active: false });
    await waitComplete(tab.id);
    await sleep(1500);
    // lazy-load 상세 이미지 로드용 스크롤
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => new Promise(r => {
      let y = 0; const iv = setInterval(() => { window.scrollTo(0, y); y += 900; if (y > document.body.scrollHeight) { clearInterval(iv); r(); } }, 80);
      setTimeout(() => { clearInterval(iv); r(); }, 5000);
    }) });
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageImages, args: [host] });
    const { thumb, details } = result || { thumb: "", details: [] };
    const base = (folder || "소싱상품").replace(/[\\/:*?"<>|]/g, "_").trim().slice(0, 60) || "소싱상품";
    const extOf = (u) => { const m = u.split("?")[0].match(/\.(jpg|jpeg|png|gif|webp)$/i); return m ? m[0].toLowerCase() : ".jpg"; };
    const dl = (url, name) => new Promise(res => {
      if (!url) return res(false);
      chrome.downloads.download({ url, filename: `${base}/${name}${extOf(url)}`, conflictAction: "overwrite" },
        () => res(!chrome.runtime.lastError));
    });
    let saved = 0;
    if (thumb && await dl(thumb, "1")) saved++;
    for (let i = 0; i < details.length; i++) { if (await dl(details[i], "s" + (i + 1))) saved++; await sleep(150); }
    return { ok: true, folder: base, hasThumb: !!thumb, detailCount: details.length, saved };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e) };
  } finally {
    if (tab) chrome.tabs.remove(tab.id).catch(() => {});
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === "ping") { sendResponse({ ok: true, version: "0.3.0" }); return true; }
  if (msg && msg.action === "coupang") {
    (async () => { sendResponse(await coupangScan(msg.keyword, msg.topN, msg.incognito)); })();
    return true;
  }
  if (msg && msg.action === "coupang_close") {     // 수집이 끝나면 시크릿 창 정리
    (async () => { await closeIncogWindow(); sendResponse({ ok: true }); })();
    return true;
  }
  if (msg && msg.action === "download") {
    (async () => { sendResponse(await downloadProduct(msg.link, msg.folder)); })();
    return true;
  }
  if (msg && msg.action === "search") {
    (async () => {
      const malls = (msg.malls || []).filter(m => SITES[m]);
      const results = [];
      for (const m of malls) { results.push(await searchSite(m, msg.keyword)); }  // 순차(세션 안전)
      sendResponse({ ok: true, results });
    })();
    return true;   // 비동기 응답
  }
});
